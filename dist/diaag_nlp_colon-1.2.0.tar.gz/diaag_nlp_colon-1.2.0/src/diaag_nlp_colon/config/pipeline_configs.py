
CURRENT_VERSIONS = {
    'colon': '1.1'
}

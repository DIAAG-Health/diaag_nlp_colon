# Diaag NLP Colon

This package uses **Natural Language Processing** techniques
to extract and serve data from raw clinical report text for colon procedures and associated pathology reports.

### Documentation
              
**[Dev Notes]**     - Helpful notes for developer       
**[Design Notes]**  - General project notes            

[Dev Notes]: documentation/DevNotes.md
[Design Notes]: documentation/DesignNotes.md

